package com.example.runningapp.other

object Constants {
    const val RUNNING_DATABASE_NAME = "running_db"
}