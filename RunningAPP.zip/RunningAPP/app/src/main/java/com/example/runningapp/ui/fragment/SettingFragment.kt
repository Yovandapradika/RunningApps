package com.example.runningapp.ui.fragment

import androidx.fragment.app.Fragment
import com.example.runningapp.R

class SettingFragment: Fragment(R.layout.fragment_setting) {
}