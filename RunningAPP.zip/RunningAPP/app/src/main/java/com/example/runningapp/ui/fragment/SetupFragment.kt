package com.example.runningapp.ui.fragment

import androidx.fragment.app.Fragment
import com.example.runningapp.R

class SetupFragment: Fragment(R.layout.fragment_setup) {
}